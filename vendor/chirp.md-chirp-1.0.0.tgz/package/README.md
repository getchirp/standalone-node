# Chirp

> A local-first visual editor for Astro content collections.
> Write and manage your markdown content in the Chirp editor — while your
> content stays as plain files in your own repo.

> **Important note:** the v1 package is not on the npm registry yet. I am doing the 
> final round of polish before making the package publicly available.

Chirp is an Astro integration that mounts the editor as a development dependency under `astro dev`.
It reads your Astro content config, builds editing forms from your zod schemas,
and writes plain `.md`/`.mdx`/`.yaml` files back into your working tree —
where you review and commit them with git like any other change.

**It only exists in dev.** When you run `astro build`, the integration
disables itself and injects nothing: no routes, no middleware, no client
code. Your production site ships exactly zero bytes of Chirp.

## Quick start

```bash
pnpm dlx astro add @chirp.md/chirp --save-dev
```

```js
// astro.config.mjs
import { defineConfig } from 'astro/config';
import chirp from '@chirp.md/chirp';

export default defineConfig({
  integrations: [chirp()],
});
```

```bash
npm run dev
```

Open [http://localhost:4321/admin](http://localhost:4321/admin) — your
collections are already there.

## Features

- **Built from your Astro collections**
  Chirp reads the collections, fields, and validation rules already defined in your content.config.ts or content.config.js. It then creates the appropriate forms, field controls, and collection views automatically. Your content remains Markdown or MDX with YAML frontmatter, and there is no second configuration to maintain.
- **Visual Markdown and MDX editing**
  Write and structure content in a familiar block editor with formatting controls, a slash menu, tables, images, and links. Chirp saves everything back as clean, readable Markdown rather than locking it into a proprietary format.
- **Changes stay safe while you work**
  Your edits are checkpointed locally in the browser while you work, then written to the project when you save. Successful saves clear that document's local checkpoint. If the same file was changed elsewhere—such as in your code editor—Chirp detects the conflict and will not overwrite it.
- **A media library for your project**
  Browse, upload, and organize images and other files stored in your project’s existing media folders.
- **Built-in taxonomies**
  Chirp automatically recognizes reference-based taxonomies such as categories and tags, then gives each one a dedicated place to browse, create, and manage its entries.
- **Fast, focused navigation**
  Move between collections without full-page reloads, find anything through the command palette with Ctrl+K, and navigate lists efficiently from the keyboard. Chirp also keeps collection data cached and refreshes it automatically when files change.
- **Secure by default, even on your own machine**
  Chirp protects local editing with strict browser security rules, blocks unauthorized write requests, prevents access outside your project, and verifies uploaded file types rather than trusting their extensions.

## Requirements

- Node.js: 22+
- Astro:   4+

Astro 4–7 are supported. Astro 4 themes can use the legacy
`src/content/config.js` or `src/content/config.ts`; Astro 5 and newer
prefer `src/content.config.js` or `src/content.config.ts`. Astro 2–3 are not
supported, due to the integration and Vite APIs predating the
middleware, route, and deferred-editor plumbing used here.

## Development and demos

The repository uses pnpm 11 and Node.js 22 or newer:

```bash
pnpm install
pnpm test
pnpm typecheck
```

The clean Astro consumer fixture in `fixtures/package-consumer` exercises the
packed package rather than a source checkout. Run the package checks with:

```bash
pnpm package:verify
```

This check also enforces the published package ceilings: 900 KB packed,
3.3 MB unpacked, 500 files, 100 shared server chunks, and the per-asset
raw/gzip limits used by the editor performance suite.

For the browser lifecycle and security checks, install a Playwright browser,
then select it when running the packed consumer smoke:

```bash
pnpm exec playwright install chromium --with-deps
pnpm package:verify:browser --browser-name=chromium
```

The supported browser names are `chromium`, `firefox`, and `webkit`.

The compatibility matrix covers Astro 4, 5, 6, and 7. Use
`pnpm package:verify:astro-matrix` when those versions are available locally;
add `--online` when an Astro version must be downloaded.

## Public package exports

The package is ESM-only. The root integration is the primary entry point. The
following extension-facing subpaths are covered by semantic versioning:

- `@chirp.md/chirp/adapters`
- `@chirp.md/chirp/content-io` and `@chirp.md/chirp/cache`
- `@chirp.md/chirp/schema`, `@chirp.md/chirp/schema-parser`, and
  `@chirp.md/chirp/schema-control-resolver`
- `@chirp.md/chirp/field-analyzer`, `@chirp.md/chirp/drawer-tabs`,
  `@chirp.md/chirp/i18n-config`, `@chirp.md/chirp/image-roots`,
  `@chirp.md/chirp/media-config`, `@chirp.md/chirp/media-fs`, and
  `@chirp.md/chirp/mount-path`
- `@chirp.md/chirp/scripts/surface-assets`,
  `@chirp.md/chirp/syntax-languages`, `@chirp.md/chirp/taxonomy-detector`, and
  `@chirp.md/chirp/package.json`

Everything below `@chirp.md/chirp/internal/` is package implementation. Those
paths exist so Chirp's injected routes and components can share modules; they
are not covered by semantic-versioning compatibility guarantees.

### Package boundaries

Public wildcards were removed before the first registry-capable release. Use a
supported barrel such as `@chirp.md/chirp/adapters` whenever one provides the
API you need. Code that intentionally accepts internal coupling must use the
explicit `/internal` namespace, for example:

```js
// Explicitly internal; not a stable public API
import { getRuntime } from '@chirp.md/chirp/internal/adapters/runtime';
```

The machine-readable classification is published in the `chirp.exports` field
of the package manifest.

For example:

```js
import chirp from '@chirp.md/chirp';
import { createAdapter } from '@chirp.md/chirp/adapters';
import { getCollectionItems } from '@chirp.md/chirp/content-io';
```

## Configuration

All options are optional:

```js
chirp({
  // Where the admin UI mounts. Default: '/admin'
  mountPath: '/admin',

  // Show collection navigation throughout the admin UI. Default: false.
  sidebar: true,

  // Expanded sidebar width. Numbers are pixels; CSS lengths are also accepted.
  // Default: '130px'.
  sidebarWidth: '16rem',

  // Remote image URLs are preserved in content but not requested by the
  // local editor unless explicitly enabled. Default: 'block'.
  remoteImages: 'allow',

  // Where content files live. Default: your project root.
  // Point `root` at a subdirectory (or git submodule) if your content
  // lives there — collection folder paths resolve against it.
  adapter: {
    type: 'filesystem',
    root: new URL('./src/content', import.meta.url).pathname,
  },

  // Media locations shown in the media library.
  // Default: your `public/` folder, plus `src/assets` or `src/images`
  // when one exists. Uploads default into `public/uploads/`.
  media: {
    paths: [
      { label: 'Uploads', dir: 'public/uploads', urlBase: '/uploads' },
    ],
    defaultUploadPath: 'Uploads',
  },

  // Optional, Vite-resolved extension contributions. Nothing is loaded when
  // these lists are empty.
  registries: {
    fields: ['./src/chirp/fields.ts'],
    blocks: ['./src/chirp/blocks.ts'],
    tiptapExtensions: ['./src/chirp/tiptap.ts'],
    commands: [{
      id: 'docs.preview',
      label: 'Preview docs',
      shortcut: 'Mod+P',
      contexts: ['editor'],
    }],
  },
})
```

Field modules default-export a map from `custom:*` component IDs to Astro
components. Block modules default-export descriptor arrays. TipTap modules
default-export extension arrays and may export a `blockRegistry` descriptor.
Registered commands appear in the command palette and shortcut overlay; when
run, they dispatch `chirp:command` on `window` with `{ detail: { id } }` and
then follow their optional `href`.

### Media notes

- Files in `public/` are served by Astro as-is — an upload to
  `public/uploads/photo.jpg` is immediately usable as `/uploads/photo.jpg`.
- Files under `src/assets` generally need to be imported by your components;
  the media library previews them through its own dev-only endpoint.

### Cloudflare

Projects using `@astrojs/cloudflare` install `@chirp.md/cloudflare` next to the
core package. Its workerd content bridge is resolved only for that adapter, so
the Node-hosted editor package no longer carries Cloudflare-specific runtime
files.

### Environment variables

| Variable | Default | Description |
|---|---|---|
| `CHIRP_MAX_UPLOAD_MB` | `10` | Max upload size in MB |
| `CHIRP_CACHE_DIR` | `.chirp/cache` | Collection cache location |
| `CHIRP_DEBUG` | unset | Enable concise Chirp lifecycle diagnostics |
| `CHIRP_TRACE` | unset | Log per-request, cache, bridge, and warm-up details |
| `CHIRP_ALLOW_REMOTE` | unset | Set to `1` only in a trusted remote dev environment such as Codespaces; keeps same-origin checks but allows non-loopback clients |

Add `.chirp/` to your `.gitignore` — it holds the local collection cache.

Chirp is local-only by default and rejects non-loopback clients. If the dev
server is reached through a trusted forwarding proxy, such as GitHub Codespaces,
start it with `CHIRP_ALLOW_REMOTE=1`. This only relaxes the network-origin
check; browser same-origin checks for mutations remain enabled. Do not enable it
on an untrusted or publicly reachable dev server.

## How saving works

1. As you edit, Chirp stores a recovery checkpoint for the current document in
   the browser's IndexedDB. It is refreshed after changes and before navigation,
   so it can restore unsaved work after a refresh, tab close, or browser crash.
   A checkpoint is not a disk write and does not change the project files.
2. **Save** sends the current structured fields and body with the source revision
   Chirp loaded. After schema validation, Chirp writes the changes atomically to
   the file in your working tree. Save has no implicit publish or workflow-state
   transition; a `draft`, `status`, or similar schema field changes only when you
   edit that field.
3. A successful Save updates the editor's source revision and clears the browser
   checkpoint for exactly the saved edit generation. If you typed again while
   the request was running, that newer work remains checkpointed and unsaved.
4. If the source changed on disk after Chirp loaded it—for example, because you
   edited it in your code editor—the revision check stops the Save before Chirp
   overwrites the file. Your local edits remain in the browser checkpoint. Reload
   the current source, then recover and reconcile those edits before saving
   again; Chirp does not merge conflicting versions automatically.
5. Saved files appear in `git status`, where you review, commit, and push them
   with your normal workflow. Your content history is your git history.

### Filesystem safety and durability

Chirp refuses to replace an existing file with no write bits, preserves the
file's supported POSIX mode bits across atomic replacement, and cleans up
exclusive temporary files after failed writes. On Windows, filesystem errors
such as read-only or locked targets are surfaced as write failures; ACLs and
extended attributes are managed by the operating system and are not copied by
Chirp.

Writes use a same-directory temporary file followed by an atomic rename. This
protects against process interruption leaving a truncated target, but Chirp
does not call `fsync` on the file or parent directory, so it does not promise
power-loss durability. Chirp intentionally does not offer a `durable-write` or
`fsync` mode: the host filesystem and your normal version-control workflow own
that durability boundary. See
[ADR-0001](./docs/decisions/0001-content-write-durability.md) for the accepted
product decision and the requirements for reconsidering it.

Before creating or replacing a file, Chirp resolves the nearest existing
ancestor and verifies that its canonical path remains inside the configured
project root. This blocks ordinary traversal and symlink-replacement attacks,
but portable Node filesystem APIs cannot pin that directory entry across the
following create or rename. A hostile local process with permission to mutate
the same directories can still replace an ancestor in that final pathname
race; filesystem permissions remain the security boundary for such a process.

## Roadmap

Local-only editing is free, forever. Nothing in the core workflow requires an account, a hosted service, or a paid add-on.

The editor exposes opt-in registries for field controls, blocks, commands, and
TipTap extensions. Empty registries add no extension modules to the runtime;
configured contributions are resolved and bundled by the host Astro/Vite app.

Future deployed-editing, Git-hosting, and media-provider packages will build on
the same optional registry and provider boundaries.

## License

Chirp is free software licensed under the [GNU Affero General Public License,
version 3 only](./LICENSE.txt) (`AGPL-3.0-only`). You may use, modify and
redistribute Chirp under the terms of that licence. Modified versions made
available to users over a network must provide those users access to the
corresponding source as required by the AGPL.

Copyright © 2026 WEBMONKEYS DESIGN STUDIO CC

Chirp.md is a trading name of WEBMONKEYS DESIGN STUDIO CC.

The Chirp name, logo and visual identity are not licensed under the AGPL. They
may not be used to imply endorsement by or affiliation with the official Chirp
project.
