# ADR-0001: Retain the host-managed content durability boundary

## Status

Accepted

## Date

2026-08-25

## Deciders

Chirp maintainers

## Context

Chirp writes user content through a same-directory exclusive temporary file and
an atomic rename. That transaction prevents an interrupted Chirp or Node process
from leaving a partially written target, but it does not call `fsync` on the
temporary file or its parent directory. A machine, kernel, filesystem, or
storage-device power loss can therefore occur after Chirp reports a successful
save but before the data is durable on storage.

Chirp is a local-first development editor. Its files remain in the user's
working tree, where the host filesystem determines storage semantics and the
normal version-control workflow provides review and retained history. The core
filesystem contract also has to remain meaningful across supported Node
platforms and filesystems. File and directory synchronization support and
failure behavior are not uniform across that matrix, particularly for syncing
directory handles on Windows.

## Decision

Chirp will retain the documented host-filesystem and version-control durability
boundary. It will not offer an opt-in `durable-write` or `fsync` mode at this
time.

A successful save means that Chirp completed its atomic replacement operation;
it does not mean that the operating system has committed the new bytes to
non-volatile storage. Documentation and UI copy must not describe a successful
save as power-loss durable. Users who require that guarantee must provide it at
the host, filesystem, or deployment layer and retain content in version
control.

This decision should be revisited if Chirp supports always-on or deployed
editing as a primary workflow, users report acknowledged-save loss under the
current boundary, or the adapter capability contract can express and verify a
portable durability guarantee.

## Options Considered

| Option | Guarantee | Portability | Save cost | Product fit |
|---|---|---|---|---|
| Retain host-managed durability | Atomic replacement; no power-loss promise | Consistent contract on supported hosts | Current cost | Best fit for local development and version-controlled content |
| Add an opt-in durable-write mode | Stronger guarantee only where synchronization succeeds | Requires capability and fallback semantics | Additional file and directory synchronization | Adds a user-visible mode whose meaning varies by host |
| Make all writes durable by default | Strongest available host guarantee | Still filesystem-dependent | Added latency on every save | Disproportionate for the current local-first workflow |

### Retain host-managed durability

Pros:

- Preserves the current low-latency save path.
- States one honest, portable core contract.
- Keeps storage policy with the host and content history with version control.

Cons:

- An acknowledged save can be lost during a power failure.
- Users needing storage durability must configure it outside Chirp.

### Add an opt-in durable-write mode

Pros:

- Could improve power-loss resistance on hosts that fully support it.
- Would avoid imposing synchronization latency on every user.

Cons:

- Needs explicit behavior for unsupported directory synchronization, Windows,
  network filesystems, and synchronization errors.
- A best-effort fallback could make the option misleading; a fail-closed mode
  could turn a successful atomic write into a reported failure after data was
  already renamed.
- Adds configuration and conformance work without evidence of demand in the
  current local-development use case.

### Make all writes durable by default

Pros:

- Avoids a mode users must discover and enable.
- Provides the strongest guarantee each supported host can expose.

Cons:

- Adds latency and storage synchronization pressure to every save.
- Cannot create identical guarantees across every supported platform and
  filesystem.
- Changes a foundational adapter contract without a demonstrated product need.

## Trade-off Analysis

The decision favors a precise cross-platform contract and interactive save
latency over a stronger but host-dependent storage guarantee. The residual
power-loss risk is real and accepted; atomic rename must not be presented as a
substitute for `fsync`. This is appropriate while Chirp operates as a local
development tool over files that users normally review and commit.

If a durability mode is proposed later, its acceptance criteria are:

1. Synchronize the completed temporary file before rename.
2. Synchronize the parent directory after rename wherever the platform exposes
   a supported operation.
3. Define Windows and unsupported-filesystem behavior explicitly.
4. Expose a capability contract rather than silently downgrading an explicitly
   requested guarantee.
5. Test successful synchronization, capability absence, file-sync failure,
   directory-sync failure, cleanup, and the post-rename error state on every
   supported platform class.

## Consequences

- Existing atomic write and rollback behavior remains unchanged.
- Chirp incurs no additional synchronization latency on saves.
- Power-loss durability remains the responsibility of the host environment.
- User-facing documentation must continue to state the limitation plainly.
- A future durable-write proposal requires a new ADR and the acceptance criteria
  above; it cannot be introduced as an undocumented best-effort toggle.

## Action Items

- [x] State the accepted durability boundary in the README.
- [x] Publish this decision with the npm package so the linked contract is
  available to package consumers.
- [x] Preserve implementation acceptance criteria for any future proposal.

