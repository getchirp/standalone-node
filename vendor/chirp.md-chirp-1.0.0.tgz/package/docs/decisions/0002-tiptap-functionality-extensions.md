# ADR-0002: Keep contextual editor behavior in Chirp's extension seam

## Status

Accepted

## Date

2026-09-01

## Deciders

Chirp maintainers

## Context

Chirp currently owns three browser behaviors that overlap with optional MIT
Tiptap functionality extensions:

- contextual text and image toolbar placement overlaps with BubbleMenu;
- block targeting and contextual block controls overlap partly with DragHandle;
- image paste and drop dispatch overlaps partly with FileHandler.

The overlap is narrower than the package names suggest. Chirp's bubble toolbar
switches between text and image controls, suppresses itself for MDX atoms and
Card-owned editing, and coordinates with the image picker and inline image
panel. Its block bar represents contiguous multi-block selection, mixed
properties, MDX atoms, nested content, and inspector actions; it is not only a
drag handle. File events are divided between an open image picker and a
specific placeholder image whose upload identity, cancellation, preview URL,
and source position Chirp owns.

Chirp already exposes `tiptapExtensions` as a host-configured registry. This
allows a consumer to add any of these extensions without making them part of
the default package or coupling Chirp's source-preserving behavior to them.

## Decision

Chirp will not add BubbleMenu, DragHandle, or FileHandler to its default editor
runtime at this time. The existing registry remains the supported pilot seam
for host applications.

BubbleMenu should be reconsidered only when one extension instance can replace
both text-selection and image-node positioning while retaining Chirp's current
suppression and focus behavior. DragHandle should be reconsidered when Chirp
adds direct block dragging and the extension demonstrably preserves MDX atoms,
nested lists, contiguous multi-selection, and block-inspector targeting.
FileHandler should be reconsidered only if file handling grows beyond image
picker and placeholder ownership, enough that central MIME dispatch removes
more code than its adapter introduces.

Any future adoption must be an opt-in experiment first and must compare
published bytes, eager browser requests, first interaction latency, and removed
Chirp code. A package is adopted only when it reduces the default runtime's
total complexity rather than moving the same state into an adapter.

The 3.29.2 pilot measured the isolated minified browser additions, with the
existing Tiptap and ProseMirror runtime treated as external, at 9,826 gzip bytes
for BubbleMenu, 9,242 gzip bytes for DragHandle, and 627 gzip bytes for
FileHandler. Package size is therefore not the rejection reason; incomplete
behavioral ownership and the resulting adapter complexity are.

## Options Considered

| Option | Default size | Behavior fit | Extensibility | Maintenance |
|---|---:|---|---|---|
| Keep Chirp behavior and use the registry for pilots | No new dependency | Exact current behavior | Available per host | Current focused controllers remain |
| Adopt all three extensions by default | Adds three packages and positioning dependencies | Requires substantial adapters | Uniform default | More upstream lifecycle surface |
| Adopt BubbleMenu only | Adds positioning runtime | Closest fit, but two anchor modes and suppression remain | Available per host today | Modest likely reduction |
| Adopt FileHandler only | Small package addition | Replaces only event dispatch | Available per host today | Little net reduction |

## Trade-off Analysis

The decision favors a smaller default dependency graph and an explicit host
extension boundary over speculative replacement. BubbleMenu is the strongest
candidate, but most of Chirp's contextual-toolbar code is behavior policy and
command state that the extension cannot remove. DragHandle does not replace the
block-property surface or Chirp's multi-selection model. FileHandler explicitly
does not own upload orchestration, which is the complex part of Chirp's path.

This is not a permanent rejection of the packages. The registry makes future
consumer pilots possible without changing Chirp core, and the acceptance gates
above make a later adoption measurable.

## Consequences

- The default package adds no optional Tiptap or Floating UI dependencies.
- Current MDX, multi-selection, inspector, picker, and upload behavior remains
  unchanged.
- Hosts can pilot the extensions through `tiptapExtensions` immediately.
- Chirp retains its manual contextual positioning until an experiment proves a
  net reduction.
- New direct block-dragging or broader file-type support must revisit this ADR.

## Action Items

- [x] Provide a formal host registry for Tiptap extensions.
- [x] Evaluate BubbleMenu, DragHandle, and FileHandler against the current
  behavior boundaries.
- [ ] Re-run a BubbleMenu prototype if its positioning dependency is already
  present for another accepted feature.
- [ ] Re-run a DragHandle prototype when direct block dragging is in scope.
- [ ] Re-run a FileHandler prototype when non-image file insertion is in scope.
